#ifndef SERIAL_H
#define SERIAL_H

#include <stdio.h>
#include <stdint.h>

#define BAUD_RATE 9600

void UART__init(uint32_t);
#endif
